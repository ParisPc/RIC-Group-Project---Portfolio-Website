    <script>
        
        /* INITIALIZE SCRIPT FOR SAVED INFO */
        document.getElementById("editorForm").addEventListener("submit", function (event) {
            event.preventDefault();

            const imgUpload = document.getElementById("imgUpload");

            /* DISPLAY UPLOADED IMAGE */
            imgUpload.addEventListener(
                "change",
                function () {
                    const file = this.files[0];

                    if (!file) return;

                    if(!fs.existsSync("uploads")) {
                        fs.mkdirSync("uploads");
                    }

                    const reader = newFileReader();

                    reader.onload = function(e) {
                        preview.style.display = "block";
                        preview.src = e.target.result;
                    };

                    reader.readAsDataURL(file);
                }
            );

            const storage = multer.diskStorage({
                destination: (
                    file,
                    req,
                    cb
                ) => {
                    cb(
                        null,
                        "uploads/"

                    );
                },

                filename: (
                    file,
                    req,
                    cb
                ) => {
                    cb(
                        null,
                        Date.new() +
                        "-" +
                        file.originalname
                    );
                }
            });

        const upload = multer({
            storage
        });

            /*SEND INFO TO DATABASE*/
            document.getElementById("editorForm").addEventListener(
                "submit",
                async function(e) {
                    e.preventDefault();

                    const editorData = new EditorData();
                    editorData.append(
                        "bio", document.getElementById("bio").value
                    );
                    
                    editorData.append(
                        "image",
                        imageUpload.files[0]
                    );

                    /* AQUIRE DATA FOR DATABASE */
                    const response = await fetch(
                        "/save-portfolio",
                        {
                            method: "POST",
                            body: editorData
                        }
                    );

                    const result = await response.json();

                    alert(result.message)
                }
            );

        });
    </script>